package orangeHRM;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;
import com.microsoft.playwright.options.AriaRole;

public class HomepagePOM {
	 private Page page;

	 
	    private Locator userName;
	    private Locator passWord;
	    private Locator loginButton;


	    public HomepagePOM(Page page) {
	        this.page = page;

	        this.userName = page.getByPlaceholder("Username");
	        this.passWord = page.getByPlaceholder("Password");
	        this.loginButton = page.getByRole(AriaRole.BUTTON,
	                new Page.GetByRoleOptions().setName("Login"));
	    }
	    
	    public void enterUsername(String username) {
	        userName.fill(username);
	    }

	    public void enterPassword(String password) {
	        passWord.fill(password);
	    }

	    public void clickLogin() {
	        loginButton.click();
	    }

}
