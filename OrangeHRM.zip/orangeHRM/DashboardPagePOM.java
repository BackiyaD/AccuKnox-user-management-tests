package orangeHRM;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.AriaRole;

public class DashboardPagePOM {
private Page page;
private Locator userDropdown;
private Locator logout;
private Locator admin;


public DashboardPagePOM(Page page) {
    this.page = page;
    this.userDropdown = page.locator("li.oxd-userdropdown");
    this.logout = page.locator("a[href='/web/index.php/auth/logout']");

    this.admin=  page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Admin"));
}
public void navigateToAdmin() {
  admin.click();
}

public void logout() {
	
  
	userDropdown.click();
	
	logout.waitFor();
	
	logout.click();
}
}
