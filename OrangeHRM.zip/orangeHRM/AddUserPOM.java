package orangeHRM;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.AriaRole;

public class AddUserPOM {
	private Page page;
	 
    private Locator role;
    private Locator employeeNameInput;

    private Locator statusDropdown;

    private Locator userName;
    private Locator createPassword;
    private Locator confirmPassword;
    private Locator saveButton;
    private Locator errorMsg;
    
    public AddUserPOM(Page page) {
    	this.page = page;
    	 this.role = page.getByText("-- Select --").first();
         this.employeeNameInput = page.getByPlaceholder("Type for hints...");
         this.statusDropdown = page.locator("//label[text()='Status']/parent::"
         		+ "div/parent::div//div[@class='oxd-select-wrapper']");
         this.userName = page.getByRole(AriaRole.TEXTBOX).nth(2);
         this.createPassword = page.getByRole(AriaRole.TEXTBOX).nth(3);
         this.confirmPassword = page.getByRole(AriaRole.TEXTBOX).nth(4);
         this.saveButton = page.getByRole(AriaRole.BUTTON,
                 new Page.GetByRoleOptions().setName("Save"));
         this.errorMsg = page.locator("//span[text()='Already exists']");
    }
    
    public void addUserinSite(String startletter, String username, String password){
    	  role.click();
          page.getByRole(
                  AriaRole.OPTION,
                  new Page.GetByRoleOptions().setName("Admin")
          ).waitFor();
          page.getByRole(
                  AriaRole.OPTION,
                  new Page.GetByRoleOptions().setName("Admin")
          ).click();
          employeeNameInput.click();
          employeeNameInput.fill(startletter);
          employeeNameInput.waitFor();
          Locator firstEmployeeOption = page.locator("//input[@placeholder='Type for hints...']"
          		+ "/ancestor::div//div[@role='listbox']//div[@role='option']//span");
          
          firstEmployeeOption.first().click();

          statusDropdown.click();
          statusDropdown.waitFor();
          page.getByText("Enabled", new Page.GetByTextOptions().setExact(true)).click();
          
          userName.fill(username);
          createPassword.fill(password);
          confirmPassword.fill(password);

        
          saveButton.click();
         
    		}
    public void verifyUserSavedSuccessfully() {
        Locator successToast = page.locator("p:has-text('Successfully Saved')");
        successToast.waitFor();
        System.out.println("User saved successfully.");
    }
    public void verifyDuplicateUsernameError() {

        errorMsg.waitFor(new Locator.WaitForOptions().setTimeout(5000));

        if (errorMsg.isVisible()) {
            System.out.println("Duplicate username validation is working correctly.");
        } else {
            System.out.println("Duplicate username validation failed.");
        }
    }
}
