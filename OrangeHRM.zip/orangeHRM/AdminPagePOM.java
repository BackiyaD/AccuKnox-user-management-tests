package orangeHRM;
import java.util.regex.Pattern;
import org.testng.Assert;
import com.microsoft.playwright.Locator; import com.microsoft.playwright.Page; import com.microsoft.playwright.options.AriaRole;
public class AdminPagePOM {


private Page page;
private Locator menuBaruserManagement;
private Locator userManagement;

private Locator job;
private Locator organization;
private Locator qualification;
private Locator addUser;
private Locator searchUserBox;
private Locator searchButton;
private Locator userRow;
private Locator adminTop;

private Locator statusDropdownIcon;

private Locator saveButton;

public AdminPagePOM(Page page) {
	this.page = page;
	   this.adminTop=    page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Admin"));
	        this.userManagement =      page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("/ User Management"));
	   this.menuBaruserManagement =   page.getByRole(AriaRole.NAVIGATION, new Page.GetByRoleOptions().setName("Topbar Menu")).getByText("User Management");
	     this.job =   page.getByText("Job", new Page.GetByTextOptions().setExact(true));
	    this.organization =  page.getByRole(AriaRole.LISTITEM).filter(new Locator.FilterOptions().setHasText("Organization"));
	    this.qualification =  page.getByRole(AriaRole.LISTITEM).filter(new Locator.FilterOptions().setHasText("Qualifications"));
	    this.addUser =page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName(" Add"));
	    
	    this.searchUserBox =page.locator("//label[text()='Username']//parent::div//parent::div//input");
	    this.searchButton = page.locator("//button[@type='submit' and text()=' Search ']");
	   
	     this.statusDropdownIcon = page.locator("form i").nth(1);
	     this.saveButton = page.getByRole(AriaRole.BUTTON,
	             new Page.GetByRoleOptions().setName("Save"));
}

public void adminPageValidation() {
	adminTop.waitFor();   

    Assert.assertTrue(
            adminTop.isVisible(),
            "Admin heading is visible"
    );

    Assert.assertTrue(
            menuBaruserManagement.isVisible(),
            "User Management menu is visible"
    );

    menuBaruserManagement.click();

    Assert.assertTrue(
            organization.isVisible(),
            "Organization menu is visible"
    );

    Assert.assertTrue(
            qualification.isVisible(),
            "Qualification menu is visible"
    );

}

public void addUser() {
	addUser.click();
}

public void searchUser(String username)  {
	searchUserBox.fill(username);
    searchButton.click();
    Locator tableBody = page.locator("div.oxd-table-body");
    tableBody.waitFor();
    Locator noRecords = page.locator("//div[@class='orangehrm-horizontal-padding orangehrm-vertical-padding']//span");

    if (noRecords.isVisible()) {
        System.out.println("User not found as expected: " + username);
        return; 
    }

    Locator usernameCell = tableBody
            .locator("div.oxd-table-card div[role='cell']")
            .filter(new Locator.FilterOptions().setHasText(username))
            .first();

    usernameCell.waitFor();

    Assert.assertEquals(usernameCell.textContent().trim(), username);

    System.out.println("User found successfully: " + username);
    }

public void editUser(String username, String newRole, String newStatus) {

	Locator userRow = page.locator("(//div[@role='row'])[3]//div[@class='oxd-table-cell-actions']//i[@class='oxd-icon bi-pencil-fill']");

		    
		    userRow.click();

		    Locator usernameInput = page.locator("//label[text()='Username']/parent::div/parent::div//input");
		  
		    usernameInput.fill(username);
		   
		        Locator roleDropdown = page.locator(
		            "//label[text()='User Role']/ancestor::div[contains(@class,'oxd-input-group')]"
		          + "//div[contains(@class,'oxd-select-text-input')]"
		        );
		        roleDropdown.click();

		        Locator roleOption = page.locator(
		            "//div[@role='listbox']//span[text()='" + newRole + "']"
		        );
		        roleOption.click();

		   
		        Locator statusDropdown = page.locator(
		            "//label[text()='Status']/ancestor::div[contains(@class,'oxd-input-group')]"
		          + "//div[contains(@class,'oxd-select-text-input')]"
		        );
		        statusDropdown.click();

		        Locator statusOption = page.locator(
		            "//div[@role='listbox']//span[text()='" + newStatus + "']"
		        );
		        statusOption.click();

		        System.out.println("Editing user: " + username);
		        saveButton.waitFor();
		        saveButton.click();

		        
		        Locator resultname = page.locator("((//div[@role='row'])[3]//div[@class='oxd-table-cell oxd-padding-cell' and @style='flex: 1 1 0%;']//div)[1]"
		        );
		        resultname.waitFor();
		        Locator resultrole = page.locator("((//div[@role='row'])[3]//div[@class='oxd-table-cell oxd-padding-cell' and @style='flex: 1 1 0%;']//div)[2]"
				        );
		        String actualRole = resultrole.textContent();
		        Locator resultstatus = page.locator("((//div[@role='row'])[3]//div[@class='oxd-table-cell oxd-padding-cell' and @style='flex: 1 1 0%;']//div)[4]"
				        );
		        String actualStatus = resultstatus.textContent();

		        Assert.assertEquals(actualRole.trim(), newRole);
		        Assert.assertEquals(actualStatus.trim(), newStatus);

		        System.out.println("Successfully updated user: " + username +
		                " | Role: " + newRole +
		                " | Status: " + newStatus);
		    }

public void editUserAndChangePassword(String username, String newPassword) {

	Locator userRow = page.locator("(//div[@role='row'])[4]//div[@class='oxd-table-cell-actions']//i[@class='oxd-icon bi-pencil-fill']");

    
    userRow.click();
    Locator usernameInput = page.locator("//label[text()='Username']/parent::div/parent::div//input");
	  
    usernameInput.fill(username);

         page.locator("label")
            .filter(new Locator.FilterOptions().setHasText("Yes"))
            .locator("i")
            .click();


    page.getByRole(AriaRole.TEXTBOX).nth(3).fill(newPassword);
    page.getByRole(AriaRole.TEXTBOX).nth(4).fill(newPassword);
    saveButton.waitFor();
    saveButton.click();
    page.locator(".oxd-toast--success").waitFor();

    System.out.println("User updated & password changed for: " + username);
}

public void deleteUser(String username) {

    
	searchUserBox.click();
	searchUserBox.fill(username);
	searchButton.click();
 
Locator rowDeleteIcon = page.locator("(//div[@role='row'])[2]//div[@class='oxd-table-cell-actions']//i[@class='oxd-icon bi-trash']");


rowDeleteIcon.click();

page.getByRole(
        AriaRole.BUTTON,
        new Page.GetByRoleOptions().setName("Yes, Delete")
).click();

boolean userStillExists = page.getByRole(
        AriaRole.ROW,
        new Page.GetByRoleOptions().setName(Pattern.compile(username, Pattern.CASE_INSENSITIVE))
).isVisible();

Assert.assertFalse(userStillExists, "User still present after deletion: " + username);

System.out.println("User deleted successfully: " + username);
}

public void searchNonExistentUser(String username) {

    searchUserBox.fill(username);
    searchButton.click();
    Locator noRecords = page.getByText("No Records Found");

    Assert.assertTrue(
            noRecords.isVisible(),
            "Expected 'No Records Found' message, but it did NOT appear for: " + username
    );

    System.out.println("NO RECORDS FOUND for: " + username);
}}