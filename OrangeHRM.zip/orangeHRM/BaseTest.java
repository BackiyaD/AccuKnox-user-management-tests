package orangeHRM;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import org.testng.annotations.Parameters;
import com.microsoft.playwright.Page;

public class BaseTest {

	
	    protected PlaywrightFactory playwrightFactory;
	    protected Page page;

	    @Parameters("browser")
	    @BeforeMethod
	    public void setUp(String browserName) {
	        playwrightFactory = new PlaywrightFactory();
	        playwrightFactory.openBrowser(browserName);
	        page = playwrightFactory.page;
	    }

	    @AfterMethod
	    public void tearDown() {
	        playwrightFactory.close();
	    }
	}