package OrangeHRMtest;

import org.testng.annotations.Test;

import orangeHRM.AddUserPOM;
import orangeHRM.AdminPagePOM;
import orangeHRM.BaseTest;
import orangeHRM.DashboardPagePOM;
import orangeHRM.HomepagePOM;
import orangeHRM.PlaywrightFactory;

public class AllpageTest extends BaseTest{
	
	
    public void loginandLogoutCheckTest() {

        HomepagePOM home = new HomepagePOM(page);

        home.enterUsername("Admin");
        home.enterPassword("admin123");
        home.clickLogin();
        
    DashboardPagePOM dash = new DashboardPagePOM(page);
       dash.logout();
    }
    
  	

	public void adminLogoutTest() {

	    HomepagePOM home = new HomepagePOM(page);

	    home.enterUsername("Admin");
	    home.enterPassword("admin123");
	    home.clickLogin();

	    DashboardPagePOM dash = new DashboardPagePOM(page);

	    dash.navigateToAdmin();
	   
	    dash.logout();
	}
	
	
	public void adminPageValidationTest() {

	    HomepagePOM home = new HomepagePOM(page);

	    home.enterUsername("Admin");
	    home.enterPassword("admin123");
	    home.clickLogin();

	    DashboardPagePOM dash = new DashboardPagePOM(page);

	    dash.navigateToAdmin();
	    
	    AdminPagePOM admin = new AdminPagePOM(page);
	    admin.adminPageValidation();
	    dash.logout();
	}
	

	public void addUser() {

	    HomepagePOM home = new HomepagePOM(page);

	    home.enterUsername("Admin");
	    home.enterPassword("admin123");
	    home.clickLogin();

	    DashboardPagePOM dash = new DashboardPagePOM(page);

	    dash.navigateToAdmin();
	    
	    AdminPagePOM admin = new AdminPagePOM(page);
	    admin.addUser();
	    
	    AddUserPOM adduser = new AddUserPOM(page);
	    adduser.addUserinSite("A", "Antman", "Akatsuki123");
	    adduser.verifyUserSavedSuccessfully();
	    dash.navigateToAdmin();
	    dash.logout();
	}
	
	
	public void verifySearchUser()  {
	    HomepagePOM home = new HomepagePOM(page);
	    home.enterUsername("Admin");
	    home.enterPassword("admin123");
	    home.clickLogin();

	    DashboardPagePOM dash = new DashboardPagePOM(page);
	    dash.navigateToAdmin();

	    AdminPagePOM admin = new AdminPagePOM(page);
	    admin.searchUser("Antman");
	    dash.logout();
	}

	public void editUserTest() {

	    HomepagePOM home = new HomepagePOM(page);
	    home.enterUsername("Admin");
	    home.enterPassword("admin123");
	    home.clickLogin();

	    DashboardPagePOM dash = new DashboardPagePOM(page);
	    dash.navigateToAdmin();

	    AdminPagePOM admin = new AdminPagePOM(page);
	    admin.editUser("Superman","Admin", "Disabled");
	    dash.logout();
	}
	

	public void changePassword() {

	    HomepagePOM home = new HomepagePOM(page);
	    home.enterUsername("Admin");
	    home.enterPassword("admin123");
	    home.clickLogin();

	    DashboardPagePOM dash = new DashboardPagePOM(page);
	    dash.navigateToAdmin();

	    AdminPagePOM admin = new AdminPagePOM(page);
	    admin.editUserAndChangePassword("Batman", "Apple123");
	   
	    dash.logout();
	}
	
	
	public void validateUserRow() {

	    HomepagePOM home = new HomepagePOM(page);
	    home.enterUsername("Admin");
	    home.enterPassword("admin123");
	    home.clickLogin();

	    DashboardPagePOM dash = new DashboardPagePOM(page);
	    dash.navigateToAdmin();

	    AdminPagePOM admin = new AdminPagePOM(page);
	    admin.searchUser("Batman");
	   	 dash.logout();
	}

	public void loginAsAUpdatedUser() {

	    HomepagePOM home = new HomepagePOM(page);
	    home.enterUsername("Batman");
	    home.enterPassword("Apple123");
	    home.clickLogin();

	    DashboardPagePOM dash = new DashboardPagePOM(page);
	   	 dash.logout();
	}
	
	public void deletetheUser() {

	    HomepagePOM home = new HomepagePOM(page);
	    home.enterUsername("Admin");
	    home.enterPassword("admin123");
	    home.clickLogin();

	    DashboardPagePOM dash = new DashboardPagePOM(page);
	    dash.navigateToAdmin();

	    AdminPagePOM admin = new AdminPagePOM(page);
	    admin.deleteUser("Batman");
	   	 dash.logout();
	}
	
	
	public void testDuplicateUsername() {
		 HomepagePOM home = new HomepagePOM(page);
		    home.enterUsername("Admin");
		    home.enterPassword("admin123");
		    home.clickLogin();

		    DashboardPagePOM dash = new DashboardPagePOM(page);
		    dash.navigateToAdmin();
		    AdminPagePOM admin = new AdminPagePOM(page);
		    admin.addUser();
		    AddUserPOM adduser = new AddUserPOM(page);
		    adduser.addUserinSite("R", "Superman", "Admin@123");
	    adduser.verifyDuplicateUsernameError();
	    dash.logout();
	}
	
	public void verifySearchNonExistentUser() {
		 HomepagePOM home = new HomepagePOM(page);
		    home.enterUsername("Admin");
		    home.enterPassword("admin123");
		    home.clickLogin();

		    DashboardPagePOM dash = new DashboardPagePOM(page);
		    dash.navigateToAdmin();
		    AdminPagePOM admin = new AdminPagePOM(page);
		    admin.searchUser("Balu"); 
		    dash.logout();
	}
}


