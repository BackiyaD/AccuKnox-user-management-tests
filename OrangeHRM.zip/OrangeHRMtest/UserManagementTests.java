package OrangeHRMtest;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class UserManagementTests extends AllpageTest {

    @BeforeClass
    public void setup() {
        System.out.println("Starting User Management Test Suite");
    }

    @Test(priority = 1)
    public void runLoginandLogout() {
        loginandLogoutCheckTest();
        System.out.println("Login and Logout Test – SUCCESS");
    }

    @Test(priority = 2)
    public void runAdminLogout() {
        adminLogoutTest();
        System.out.println("Admin Logout Test – SUCCESS");
    }

    @Test(priority = 3)
    public void runAdminPageValidation() {
        adminPageValidationTest();
        System.out.println("Admin Page Validation Test – SUCCESS");
    }

    @Test(priority = 4)
    public void runAddUser() {
        addUser();
        System.out.println("Add User Test – SUCCESS");
    }

    @Test(priority = 5)
    public void runVerifySearchUser()  {
        verifySearchUser();
        System.out.println("Search User Test – SUCCESS");
    }

    @Test(priority = 6)
    public void runEditUser() {
        editUserTest();
        System.out.println("Edit User Test – SUCCESS");
    }

    @Test(priority = 7)
    public void runChangePassword() {
        changePassword();
        System.out.println("Change Password Test – SUCCESS");
    }

    @Test(priority = 8)
    public void runValidateUserRow() {
        validateUserRow();
        System.out.println("Validate User Row Test – SUCCESS");
    }

    @Test(priority = 9)
    public void runUpdatedUserLogin() {
        loginAsAUpdatedUser();
        System.out.println("Login as Updated User Test – SUCCESS");
    }

    @Test(priority = 10)
    public void runDeleteUser() {
        deletetheUser();
        System.out.println("Delete User Test – SUCCESS");
    }

    @Test(priority = 11)
    public void runDuplicateUserTest() {
        testDuplicateUsername();
        System.out.println("Duplicate Username Validation Test – SUCCESS");
    }

    @Test(priority = 12)
    public void runSearchNonExistent() {
        verifySearchNonExistentUser();
        System.out.println("Search Non-Existent User Test – SUCCESS");
    }
}
